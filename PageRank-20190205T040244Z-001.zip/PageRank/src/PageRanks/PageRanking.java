package PageRanks;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.collections15.Transformer;

import edu.uci.ics.jung.algorithms.scoring.PageRank;
import edu.uci.ics.jung.graph.DirectedGraph;
import edu.uci.ics.jung.graph.DirectedSparseGraph;

public class PageRanking {

    DirectedGraph<Integer, String> g =
        new DirectedSparseGraph<Integer, String>();
    
    private void readFile(String filename, String delim) throws IOException {

        FileReader fr = new FileReader(filename);
        BufferedReader br = new BufferedReader(fr);

        String line;

        while ((line = br.readLine()) != null) {
            String[] result = line.split(delim);
            //System.out.println(result[0]);
            g.addEdge(result[0] + " " + result[1],
                Integer.parseInt(result[0]),
                Integer.parseInt(result[1]));
        }

        br.close();
    }
    
    private static HashMap sortByValues(HashMap map) { 
        List list = new LinkedList(map.entrySet());
        // Defined Custom Comparator here
        Collections.sort(list, new Comparator() {
             public int compare(Object o1, Object o2) {
                return ((Comparable) ((Map.Entry) (o1)).getValue())
                   .compareTo(((Map.Entry) (o2)).getValue());
             }
        });

        // Here I am copying the sorted list in HashMap
        // using LinkedHashMap to preserve the insertion order
        HashMap sortedHashMap = new LinkedHashMap();
        for (Iterator it = list.iterator(); it.hasNext();) {
               Map.Entry entry = (Map.Entry) it.next();
               sortedHashMap.put(entry.getKey(), entry.getValue());
        } 
        return sortedHashMap;
   }
 

    
    public static void main(String arg[]) throws IOException {
    	  PrintWriter writer = new PrintWriter("output.txt", "UTF-8");
        PageRanking prc = new PageRanking();
        HashMap<Integer, Double> scorevalues=new HashMap<Integer, Double>();
        
        prc.readFile("web-Stanford.txt","\\s");
        //PageRank<Integer, String> pr =new PageRank<Integer, String>(prc.g, 0.15);
        PageRank<Integer,String> pr=new PageRank<Integer,String>(prc.g,0.15);
        pr.evaluate();
        double sum = 0;
        Set<Integer> sortedVerticesSet =
            new TreeSet<Integer>(prc.g.getVertices());
        for (Integer v : sortedVerticesSet) {
            Double score = pr.getVertexScore(v);
            scorevalues.put(v,score);
            sum += score;      
            
            System.out.println(v + " = " + score);
        }
        Map<Integer, String> map = sortByValues(scorevalues);
        writer.println(map);
        writer.close();
        
        System.out.println("s = " + sum);
    }
}