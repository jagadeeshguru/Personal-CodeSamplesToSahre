package application;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.DisplayMode;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.RenderingHints;
import java.awt.ScrollPane;
import java.awt.Scrollbar;
import java.awt.Toolkit;
import java.awt.geom.Arc2D;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Spliterator;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import javax.swing.SpringLayout;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;

import com.jgoodies.forms.layout.FormLayout;
import javax.swing.JSlider;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import java.awt.FlowLayout;

public class MainSimulatorWindow{
	 JFrame myframe;
	 static JPanel pane;
	JScrollPane scroll;
	static JPanel testPanel;
	static JPanel panel = new JPanel(new GridLayout(2, 2));
	JFrame frame = new JFrame("HIV Simulator");
    public static void main(String[] args) {
        new MainSimulatorWindow();
    }

    public MainSimulatorWindow() {
        EventQueue.invokeLater(new Runnable() {
            
        	@Override
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
                }
                
                Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
                double width = screenSize.getWidth();
                double height = screenSize.getHeight();
                
                JSplitPane splitPane = new JSplitPane();
                 splitPane.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
                //splitPane.setDividerLocation(frame.getWidth()-frame.getWidth()/3);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                 frame.getContentPane().setLayout(new BorderLayout());                 
                 
                  
                 //frame.getContentPane().add(simulpane,BorderLayout.NORTH);
                 
                 
                splitPane.setResizeWeight(1.0);
                JMenuBar menuBar = new JMenuBar();
                JMenu fileMenu = new JMenu("File");
                menuBar.add(fileMenu);
                JMenuItem openAction = new JMenuItem("Open");
                JMenuItem exitAction = new JMenuItem("Exit");
                
                fileMenu.add(openAction);
                fileMenu.add(exitAction);
                 
                simulationPane simulpane=new simulationPane();
                
                JPanel component=new JPanel();
                //component.setLayout(new BorderLayout());
                //component.add(simulpane,BorderLayout.NORTH);
                
                splitPane.setLeftComponent(simulpane);
                Border border = new MatteBorder(1, 1, 0, 0, Color.BLACK);
                splitPane.setBorder(border);
                frame.getContentPane().add(splitPane,BorderLayout.CENTER);
                
                
                
                //frame.getContentPane().add(simulpane,BorderLayout.NORTH);
               // frame.getContentPane().add(menuBar,BorderLayout.NORTH);
                frame.getContentPane().add(new RangeSlider(), BorderLayout.SOUTH);
                frame.pack();
                frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);       
                
            }
        });
    }
    }