package application;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.geom.Arc2D;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.MatteBorder;

public class simulationPane extends JPanel {
	//static FilePicker choose=new FilePicker();
	static Arc2D arc=null;
	static int angle=360;
	Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    double width = screenSize.getWidth();
    double height = screenSize.getHeight();
  int wid=(int)(width-width/10);
   int hei=(int)(height-height/20);

	
        public simulationPane() {
            setLayout(new GridBagLayout());
            FilePicker choose=new FilePicker();
            Map<Integer,List<Integer>> b = new HashMap<Integer, List<Integer>>();
           int linecount=choose.linecount();
           int divangle=choose.angle();
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.fill=GridBagConstraints.HORIZONTAL;
            for (int row = 0; row <choose.height(); row++) {
                for (int col = 0; col < choose.width(); col++) {
                	
                	gbc.gridx = col;
                    gbc.gridy = row;
                    gbc.ipadx = 68; 
                    gbc.ipady =68;
                    int rownum=row;
                    int colnum=col;
                       blockPane cellPane = new blockPane(choose.height(),choose.width()){
                         public void paintComponent(Graphics grphcs) {
                        	 
                        	 Insets insets = getInsets();
                             super.paintComponent(grphcs);
                             Graphics2D g2d = (Graphics2D) grphcs;
                             g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                                                      
                             int radius = Math.min(getWidth()+800, getHeight()+800);
                             int x = insets.left + ((getWidth() - radius) / 2);
                             int y = insets.right + ((getHeight() - radius) / 2);
                             
                             for(int i=0;i<linecount;i++)
                             {
                            	 
                                arc = new Arc2D.Double(x, y, radius, radius, angle, divangle, Arc2D.PIE);                                
                                
                             	Color result = choose.color(rownum, colnum, i);   
                             	g2d.setColor(result);
                             	g2d.fill(arc);
                             	angle=angle-divangle;     

                             }
                    	 }
                    };
                    Border border = null;
                    if (row < choose.height()) {
                        if (col < choose.width()) {
                            border = new MatteBorder(1, 1, 0, 0, Color.GRAY);
                        } else {
                            border = new MatteBorder(1, 1, 0, 1, Color.GRAY);
                        }
                    } else {
                        if (col < choose.width()) {
                            border = new MatteBorder(1, 1, 1, 0, Color.GRAY);
                        } else {
                            border = new MatteBorder(1, 1, 1, 1, Color.GRAY);
                        }
                    }
                    
                    cellPane.setBorder(border);
                    cellPane.setBorder(BorderFactory.createLineBorder(Color.black));
                    add(cellPane, gbc);         
                }
            }
        }		
      }
        