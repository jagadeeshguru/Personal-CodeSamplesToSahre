package application;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.security.Timestamp;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class RangeSlider extends JPanel {

    private JLabel rangeSliderLabel1 = new JLabel();
    private JLabel rangeSliderValue1 = new JLabel();
    private JLabel rangeSliderLabel2 = new JLabel();
    private JLabel rangeSliderValue2 = new JLabel();
    private JLabel timeStep=new JLabel();
    private RangeSliderClass rangeSlider = new RangeSliderClass();

    public RangeSlider() {
        setBorder(BorderFactory.createEmptyBorder(7, 7, 7, 7));
        setLayout(new GridBagLayout());
        
        rangeSliderLabel1.setText("Lower value:");
        rangeSliderLabel2.setText("Upper value:");
        timeStep.setText("Time Step");
        rangeSliderValue1.setHorizontalAlignment(JLabel.LEFT);
        rangeSliderValue2.setHorizontalAlignment(JLabel.LEFT);
        timeStep.setFont(new Font("Courier New", Font.BOLD, 30));
        timeStep.setForeground(Color.RED);
        timeStep.setHorizontalAlignment(JLabel.LEFT);
        //rangeSlider.setPreferredSize(new Dimension(240, rangeSlider.getPreferredSize().height));   
        rangeSlider.setMajorTickSpacing(1);
        rangeSlider.setMinorTickSpacing(1);
        if(FilePicker.lineCount>50)
        {
        rangeSlider.setMajorTickSpacing(5);
        rangeSlider.setMinorTickSpacing(1);
        }  	
        rangeSlider.setPaintTicks(true);
        rangeSlider.setPaintLabels(true);
        rangeSlider.setMinimum(0);
        rangeSlider.setMaximum(FilePicker.lineCount);
        Dimension dim= new Dimension(1000, 100);
        rangeSlider.setPreferredSize(dim);
        
        JPanel sliderPanel = new JPanel();
        //sliderPanel.add(timeStep,BorderLayout.NORTH);
        rangeSlider.setBorder(BorderFactory.createLineBorder(Color.black));
        sliderPanel.add(rangeSlider,BorderLayout.SOUTH);
        
        // Add listener to update display.
        rangeSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                RangeSliderClass slider = (RangeSliderClass) e.getSource();
                rangeSliderValue1.setText(String.valueOf(slider.getValue()));
                rangeSliderValue2.setText(String.valueOf(slider.getUpperValue()));
            }
        });

        add(rangeSliderLabel1, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0,
            GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(0, 0, 3, 3), 0, 0));
        add(rangeSliderValue1, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0,
            GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(0, 0, 3, 0), 0, 0));
        add(rangeSliderLabel2, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0,
            GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(0, 0, 3, 3), 0, 0));
        add(rangeSliderValue2, new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0,
            GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(0, 0, 6, 0), 0, 0));
        add(timeStep, new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0,
                GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 7, 0), 0, 0));
        add(rangeSlider      , new GridBagConstraints(0, 2, 2, 1, 0.0, 0.0,
            GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
        display();
    }
    
    public void display() {
        rangeSlider.setValue(0);
        rangeSlider.setUpperValue(FilePicker.lineCount);
        rangeSliderValue1.setText(String.valueOf(rangeSlider.getValue()));
        rangeSliderValue2.setText(String.valueOf(rangeSlider.getUpperValue()));
    }    
}
