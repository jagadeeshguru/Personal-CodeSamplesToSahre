package application;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JPanel;

public class blockPane extends JPanel {

        private Color defaultBackground;
        
        int wid,hei;
        
        
        public blockPane(int height,int width){
        	setDimensions(height, width);
        	
        	//this.width=width;
        	//this.height=height;
        }

        public void setDimensions(int x, int y)
        {
        	Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            double width = screenSize.getWidth();
            double height = screenSize.getHeight();
           wid=(int)(width-width/10);
           hei=(int)(height-height/10);
           
           wid=wid/y;
           hei=hei/x;
           
          // System.out.println("values:"+wid);
           //System.out.println("values:"+hei);
           
           
        }
        
        @Override
        public Dimension getPreferredSize() {
            return new Dimension(100,150);            
        }
}