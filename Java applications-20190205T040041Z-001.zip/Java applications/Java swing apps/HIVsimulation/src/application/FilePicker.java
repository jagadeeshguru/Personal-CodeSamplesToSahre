package application;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream.GetField;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.print.attribute.IntegerSyntax;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import org.apache.commons.lang3.StringUtils;

class FilePicker extends JDialog {
    private JLabel label;
    private static JTextField textField;
    private JButton browsebutton;
    private JButton showbutton;
    private JButton cancelbutton;
    private static boolean debug=true;//debug mode to get more output as we test the code
    private static String dir=""; 
    private JFileChooser fileChooser;
    static int width=0;
	static int height=0;
	String textFieldLabel="Pick Your File"; 
	String buttonLabel="Browse";
	String buttonLabel1="Show";
	String buttonLabel2="Cancel";
	static int lineCount=0,timestep=0;
    static ArrayList<String> list = new ArrayList<String>();
    static ArrayList<String> values = new ArrayList<String>();
    static Map<Integer, List<String>> map = new HashMap<Integer, List<String>>();
    static Map<Integer, List<String>> gridvalmap = new HashMap<Integer, List<String>>();
    static Map<Integer,List<String>> angles = new HashMap<Integer, List<String>>();
    static Map<String,Color> states=new HashMap<String,Color>();
    
    public FilePicker() {    
    	
    	JPanel panel=new JPanel();
    	panel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
        label = new JLabel(textFieldLabel);
         
        textField = new JTextField(30);
        browsebutton = new JButton(buttonLabel);
        showbutton=new JButton(buttonLabel1);
        cancelbutton=new JButton(buttonLabel2); 
        browsebutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                browsebuttonActionPerformed(evt);            
            }
        });
        showbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                try {
					showbuttonActionPerformed(evt);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}            
            }
        });
        cancelbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                cancelbuttonActionPerformed(evt);            
            }
        });
        panel.add(label);
        panel.add(textField);
        panel.add(browsebutton);
        panel.add(showbutton); 
        panel.add(cancelbutton);

        //JDialog dialog = new JDialog(this.getParent().,"Browse Your file", true);
        //dialog.getContentPane().add(new FilePicker());
        
        setAlwaysOnTop(true);
        setTitle("Browse Your File");
        add(panel);
        pack();
        setSize(500, 150);
        setLocationRelativeTo(this.getParent());
        setModalityType(ModalityType.APPLICATION_MODAL);
        setVisible(true);
    }
     
    private void browsebuttonActionPerformed(ActionEvent evt) {
    	fileChooser = new JFileChooser();
        int rVal = fileChooser.showOpenDialog(FilePicker.this);
        if (rVal == JFileChooser.APPROVE_OPTION) {
          textField.setText(fileChooser.getSelectedFile().getName());
          dir=fileChooser.getCurrentDirectory().toString()+"/";
        }
        if (rVal == JFileChooser.CANCEL_OPTION) {
        	cancelPressed();
        }
    }
    
    private void showbuttonActionPerformed(ActionEvent evt) throws IOException {
     readfile();
     setDimensions();
     modify();
     putValues();
     gridValues();
     acquireStates();
     dispose();
    }
    
    private void cancelbuttonActionPerformed(ActionEvent evt) {
    	dispose();
        
    }
    public static int cancelPressed()
    {
       return 0;
    }
    public static String getfilename()
    {   
    	return dir+textField.getText();
    }
    
    public static void readfile() throws IOException
    {   	
    	String filename=getfilename();
    	Scanner s = new Scanner(new File(filename));
    	
    	while (s.hasNext()){
    	    list.add(s.next());
    	}
    	lineCount=list.size();
    	//if(debug) System.out.println("Time steps "+lineCount);
    	s.close();
    	timestep=lineCount;
    }
  
    //Functtion to set the dimensions for the grid display
    public void setDimensions(){
    	height=StringUtils.countMatches(list.get(0), "("); //counts the number of lines.
    	width=StringUtils.countMatches(list.get(0).substring(0, list.get(0).indexOf(")")), ",")+1;//count columns 
    	//if(debug)
    		//System.out.println("Lines "+height+", columns "+width);
    }
     
    //removing [,(,),] after input file parsed.
    public static void modify()
    {
    	for(int j=0;j<list.size();j++)
    	{
    		String s=list.get(j);
    		s=s.replace("[","");
    		s=s.replace("(","");
    		s=s.replace(")","");
    		s=s.replace("]","");
    		//s=s.replace(",",""); BECAUSE w
    		//we need commas to know what separates the states
    		values.add(j,s);
    	}
    }
    
    // adding tokenized values to map.
    
	public static void putValues(){   	
    	//System.out.println(values.get(0));
    	for(int j=0; j < lineCount; j++)
    	{
    		//System.out.println("length"+values.get(0).length());
    		//Lines look like 1,0,1,0,1,0,1,0,1,0
    		StringTokenizer tokenizer = new StringTokenizer(values.get(j).toString(),",");
    		//now divided into individual tokens: 1 0 1 ...
    		List<String> lineContent = new ArrayList<String>();
    		while(tokenizer.hasMoreTokens())
    			lineContent.add(tokenizer.nextToken());
    		map.put(j,lineContent);    	
    	}
    }
    
    
    public static void gridValues()
    {
    	for(int i=0;i<map.get(0).size();i++)
    	{
    		List<String> values=new ArrayList<String>();
    		for(int j=0;j<lineCount;j++)
    		{
    			values.add(map.get(j).get(i));
    			
    		}
    		gridvalmap.put(i,values);    		
    	}
    }
    
    public static void acquireStates(){
    	//parse  the matrices and add the states to a hashmap
    	//HashMap<String,Color> mapping = new HashMap<String,Color>();
    	//add the states
    	
    	//Open a file containing the different colours, store it in a List, AND CLOSE THE FILE :-)
    	List<Color> colourList = new LinkedList<Color>();
    	//		... open the file and add to the list ...
    	Iterator<Color> it = colourList.iterator();
    	for(int i=0;i<map.size();i++)
    	{
    		for(int j=0;j<map.get(0).size();j++)
    		{
    			String temp;
    			temp=map.get(i).get(j);
    			if(!(states.containsKey(temp)))
    			{
    				states.put(temp,Color.getHSBColor(new Random().nextFloat(),new Random().nextFloat(), new Random().nextFloat()));
    				//states.put(temp, it.next());
    			}    			
    		}
    	}
    	
    	}
       
    public static void updateTimeStep()
    {
    	RangeSliderClass range=new RangeSliderClass();
    	int lower=range.getValue();
    	int higher=range.getUpperValue();
    	timestep=higher-lower;
    }
    
    /*
     * Maps the block number to its list of values over time
     * 'Block number' refers to the linear position of the cell, e.g. position (x,y) becomes x+width*y
     */

    /* Function to return Color for sector
     * 
     */
    public Color color(int x,int y,int count)
    {
    	int grid=width*x+y;    	
    	return states.get(gridvalmap.get(grid).get(count));
    }
    
    public static Map<String,Color> giveStates(){
		return states;	
    }
    
    public int angle()
    {
    	int angle=0;
    	if(lineCount>0)
    	angle=360/lineCount;
		return angle;    	
    }
    
    public int linecount()
    {
    	return lineCount;
    }
    
    public int width()
    {
    	return width;
    }
    
    public int height()
    {
    	return height;
    }
    
    public int timeStep()
    {
    	return timestep;
    }
}