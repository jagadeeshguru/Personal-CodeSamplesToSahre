/**
 * ******************************************************************
 * Class: CSCI 470-1 Program: Assignment 2 Author: Guru Jagadeesh Babu Z-number:
 * z1784615 Date Due: 10/03/16
 *
 * Purpose: Program to calculate the plus,minus,divide,times and clear as the real calculator.
 *
 *
 * Notes: (optional) any special notes to your T.A. or other readers
 *
 ********************************************************************/
package democalculator;

/**
 *
 * @author Guru
 */
public class DemoCalculator {
    /**
     * Mail class from where the program begins the execution
     */
    public static void main(String[] args) {
        Calculator b= new Calculator();           // Creating a new isnatnce for the claculator class.
    }    
}
