/**
 * ******************************************************************
 * Class: CSCI 470-1 Program: Assignment 2 Author: Guru Jagadeesh Babu Z-number:
 * z1784615 Date Due: 10/03/16
 *
 * Purpose: Program to calculate the plus,minus,divide,times and clear as the real calculator.
 *
 *
 * Notes: (optional) any special notes to your T.A. or other readers
 *
 ********************************************************************/
package democalculator;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 *
 * @author Guru
 */
/* Starter Calculator for Prof. Freedman's Java Class */
public class Calculator implements ActionListener {

    // Declaration of the variables
    private JFrame frame;
    private JTextField xfield, yfield;
    private JLabel rslt;
    private JButton plusButton, minusButton, timesButton, divideButton, clearButton;
    private JPanel xpanel, buttonPanel;

    public Calculator() {

        frame = new JFrame();                                        // creating a new frame
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);           // Setting properties for the frame
        frame.setLayout(new BorderLayout());

        xpanel = new JPanel();                                     // creating a new panel
        buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(1, 5));
        xpanel.setBorder(BorderFactory.createEtchedBorder());
        buttonPanel.setBorder(BorderFactory.createEtchedBorder());
        xpanel.setLayout(new GridLayout(3, 2));                            // setting a layout for xpanel

        xpanel.add(new JLabel("x="));
        xfield = new JTextField("0", 5);                                
        xfield.setHorizontalAlignment(JTextField.RIGHT);                     // settign the text alignment to right
        xpanel.add(xfield);                                             //adding xfield to xpanel

        xpanel.add(new JLabel("y="));                                    // creating a new label
        yfield = new JTextField("0", 5);
        yfield.setHorizontalAlignment(JTextField.RIGHT);
        xpanel.add(yfield);                                          // adding yfield to xpanel

        xpanel.add(new JLabel("Result"));                           // addding a new label
        rslt = new JLabel("0");
        rslt.setForeground(Color.red);                                // setting the foreground color
        rslt.setOpaque(true);
        rslt.setBackground(Color.yellow);
        xpanel.add(rslt);
        frame.add(xpanel, BorderLayout.NORTH);

        //creating new buttons
        plusButton = new JButton("Plus");                     
        minusButton = new JButton("Minus");
        timesButton = new JButton("Times");
        divideButton = new JButton("Divide");
        clearButton = new JButton("Clear");

        //adding buttons to the buttons panel
        buttonPanel.add(plusButton);
        buttonPanel.add(minusButton);
        buttonPanel.add(timesButton);
        buttonPanel.add(divideButton);
        buttonPanel.add(clearButton);

        frame.add(buttonPanel, BorderLayout.SOUTH);

        //adding action lsitners
        minusButton.addActionListener(this);
        plusButton.addActionListener(this);
        timesButton.addActionListener(this);
        divideButton.addActionListener(this);
        clearButton.addActionListener(this);

        frame.pack();
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent event) {
        double x = 0, y = 0;
        int testXvalue = 0, testYvalue;

        String xText = xfield.getText();                // getting the texts of textfields to strings
        String yText = yfield.getText();
        yfield.setForeground(Color.black);

        try {                                                   //try catch for the x field value
            x = Double.parseDouble(xText);     
            testXvalue = 1;
        } catch (NumberFormatException e) {
            xfield.setForeground(Color.red);
            rslt.setText("Error");                          // setting the error text for result
            testXvalue = 0;
        }
        try {                                            //try catch for the y field value
            y = Double.parseDouble(yText);
            testYvalue = 1;
        } catch (NumberFormatException e) {
            yfield.setForeground(Color.red);
            rslt.setText("Error");                    //setting error text for result
            testYvalue = 0;
        }

        if (testXvalue == 1 && testYvalue == 1) {                  // checking condition for if bot x and y field values are valid.
            xfield.setForeground(Color.black);
            yfield.setForeground(Color.black);

            if (event.getSource() == minusButton) {                //checking if minus button pressed
                rslt.setText(Double.toString(x - y));
            }
            if (event.getSource() == plusButton) {               //checking if plus button pressed
                rslt.setText(Double.toString(x + y));
            }
            if (event.getSource() == divideButton) {             // checking if divide button pressed
                if (y == '0') {
                    rslt.setText("divide by zero");
                    yfield.setForeground(Color.red);
                } else {
                    rslt.setText(Double.toString(x / y));
                }
            }
            if (event.getSource() == timesButton) {              // checking if times button pressed
                rslt.setText(Double.toString(x * y));
            }
        }
         if (event.getSource() == clearButton) {               // checking if clear button pressed
                rslt.setText("0");
                xfield.setText("0");
                yfield.setText("0");
            }
    }
}
