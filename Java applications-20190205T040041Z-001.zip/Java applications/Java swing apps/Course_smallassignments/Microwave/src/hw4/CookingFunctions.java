/**
 * ******************************************************************
 * Class: CSCI 470-1 Program: Assignment 2 Author: Guru Jagadeesh Babu Z-number:
 * z1784615 Date Due: 11/16/16
 *
 * Purpose: interface for CookingFunctions.
 *
 *
 * Notes: (optional) any special notes to your T.A. or other readers
 *
 ********************************************************************/
package hw4;

/**
 *
 * @author Guru
 */
public interface CookingFunctions {            //interface for Cooking functions
    
    public void Reset();
    
}
