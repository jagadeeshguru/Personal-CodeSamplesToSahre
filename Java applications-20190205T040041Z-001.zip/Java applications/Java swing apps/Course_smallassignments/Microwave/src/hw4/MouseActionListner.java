/**
 * ******************************************************************
 * Class: CSCI 470-1 Program: Assignment 2 Author: Guru Jagadeesh Babu Z-number:
 * z1784615 Date Due: 16/16/16
 *
 * Purpose: Class for implementing the action listner for menuitems.
 *
 *
 * Notes: (optional) any special notes to your T.A. or other readers
 *
 ********************************************************************/
package hw4;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 *
 * @author Guru
 */
public class MouseActionListner implements ActionListener {
  public void actionPerformed(ActionEvent e) {
      
    if(e.getActionCommand().toString().equals("Apple")){
        if(Microwave1.createddevices==Microwave1.maxdevices)
        {
            JOptionPane.showMessageDialog(Microwave.mainframe, "Cant create new Apple more than 2 times");       
        }
        else{
        Microwave1 mw1= new Microwave1() {};
        Microwave.panelList.add(mw1);
        Microwave1.createddevices+=1;
        Microwave.mainframe.getContentPane().add(mw1);
        Microwave.mainframe.validate();
        Microwave.mainframe.revalidate();
        }
    }
     if(e.getActionCommand().toString().equals("Baker")){
         if(Microwave2.createddevices==Microwave2.maxdevices)
        {
            JOptionPane.showMessageDialog(Microwave.mainframe, "Cant create new Baker more than 2 times");       
        }
         else{
        Microwave2 mw2= new Microwave2() {};
        Microwave.panelList.add(mw2);
        Microwave2.createddevices+=1;
        Microwave.mainframe.getContentPane().add(mw2);
        Microwave.mainframe.validate();
        Microwave.mainframe.revalidate();
         }
    }
      if(e.getActionCommand().toString().equals("Cook")){
           if(Microwave3.createddevices==Microwave3.maxdevices)
        {
            JOptionPane.showMessageDialog(Microwave.mainframe, "Cant create new cook more than 2 times");       
        }
         else{
        Microwave3 mw3= new Microwave3() {};
        Microwave.panelList.add(mw3);
        Microwave3.createddevices+=1;
        Microwave.mainframe.getContentPane().add(mw3);
        Microwave.mainframe.validate();
        Microwave.mainframe.revalidate();
           }
    }
       if(e.getActionCommand().toString().equals("Dinner")){
            if(Microwave4.createddevices==Microwave4.maxdevices)
        {
            JOptionPane.showMessageDialog(Microwave.mainframe, "Cant create new Dinner moree than 2 times");       
        }
         else{
        Microwave4 mw4= new Microwave4() {};
        Microwave.panelList.add(mw4);
        Microwave4.createddevices+=1;
        Microwave.mainframe.getContentPane().add(mw4);
        Microwave.mainframe.validate();
        Microwave.mainframe.revalidate();
          }
    }
       if(e.getActionCommand().toString().equals("Reset")){
        for(CookingFunctions n : Microwave.panelList){
            n.Reset();
        }
    }
  }
    
}
