import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JList;
import javax.swing.JPanel;


/****************************************************
Author - Guru Jagadeesh Babu
Description: EditWindow class extends the java feature JDialog
which take the file name of existying porfolio and opens it for
editing.
*****************************************************/
class EditWindow extends JDialog{
	  ArrayList<String> nodesfromfile=new ArrayList<String>();
	  String Filename;
	  public  EditWindow() {
		  JPanel panel= new JPanel();
		  JComboBox c = new JComboBox();
		  FilenameFilter filter = new FilenameFilter() {
		        public boolean accept(File directory, String fileName) {
		            return fileName.endsWith(".txt"); //assumes all portfolios are stored within the CURRENT folder as .txt files
		        }
		        };
		  JList displayList = new JList(new File(".//").listFiles(filter));
	        displayList.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
	        JComboBox<JList> combo= new JComboBox<JList>();
	        for(int i=0;i<displayList.getModel().getSize();i++)
	        {
	        	c.addItem(displayList.getModel().getElementAt(i));
	        }
	        c.setEditable(false);
	        c.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent e) {
					try {
						
						Filename=c.getSelectedItem().toString();
						//Combo cb= new Combo();						
						Parsetextfile(Filename);
						//System.out.println(nodesfromfile);
						//Combo.setnodes();
						//Combo.Nodesfromfile=nodesfromfile;	
						uncheck();
                        checknodes();
					    dispose();
					    
					} catch (IOException e1) {
						e1.printStackTrace();
					
					}					
				}	     
	        });
	        
	        
	        JButton okbutton=new JButton("Ok");
	        setPreferredSize(new Dimension(500, 100));
	        panel.add(c);
   	       // panel.add(okbutton);
	        add(panel);
	        //add(okbutton,BorderLayout.SOUTH);
	        pack();
	        setVisible(true);
	        setLocationRelativeTo(null);
	        setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
	        okbutton.addActionListener(new ActionListener() {
	        	
				@Override
				public void actionPerformed(ActionEvent e) {
                try {
                	
					Parsetextfile(Filename);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				}
			});
	    }	   
	  
	  /*This function unchkecs all the checked nodes and reset it to the original position.*/
	  public void uncheck(){
		  for(int i=0;i<Combo.totalnodes.length;i++)
		  {
			  Combo.totalnodes[i].isSelected=false;
		  }
		  Combo.panel.repaint();
		  for(int i=0;i<Combo.roots.length;i++)
		  {
			  Combo.roots[i].isSelected=false;
		  }
	  }
	  
	  
	  /*This function checks the nodes as of the protfolio file selected by the user  */
	  public void checknodes()
	  {
		  
		  for(int i=0;i<Combo.totalnodes.length;i++)
		  {
			  for(int j=0;j<nodesfromfile.size();j++)
			  {
				  if(Combo.totalnodes[i].toString().equals(nodesfromfile.get(j)))
				  {
					  System.out.println("YOu got matching");
					  Combo.totalnodes[i].isSelected=true;
				  }
				 
			  }		  
		  }
		  
		  for(int i=0;i<Combo.roots.length;i++)
		  {
			  for(int j=0;j<nodesfromfile.size();j++)
			  {
				  if(Combo.roots[i].equals(nodesfromfile.get(j)))
				  {
					  System.out.println("YOu got matching");
					  Combo.roots[i].isSelected=true;
				  }
				 
			  }				 
		  }

		  Combo.panel.repaint();
	  }
	  
	  
	  /*Parses the file which was selected by the user to edit*/
	  public void Parsetextfile(String filename) throws IOException
	  {
		  FileReader input = new FileReader(filename);
		  BufferedReader bufRead = new BufferedReader(input);
		  String myLine = null;

		  while ( (myLine = bufRead.readLine()) != null)
		  {    
		     nodesfromfile.add(myLine);
		  
		  }
		  System.out.println(filename);
	  }
	  
	  /*Returns the arraylist of containing nodes from file*/
	  public ArrayList<String> nodes()
	  {
		  return nodesfromfile;
	  }
	  
}