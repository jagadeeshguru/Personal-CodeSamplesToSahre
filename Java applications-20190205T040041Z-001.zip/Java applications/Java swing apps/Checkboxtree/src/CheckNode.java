import java.util.Enumeration;

import javax.swing.tree.DefaultMutableTreeNode;


/****************************************************
Author - Guru Jagadeesh Babu
Description: Class CheckNode extends DefaultMutableTreeNode class.
This class is useful while renering the tree nodes and while repainting the tree
everytime when we check and uncheck.
*****************************************************/

class CheckNode extends DefaultMutableTreeNode {

  public final static int SINGLE_SELECTION = 0;

  public final static int DIG_IN_SELECTION = 4;

  protected int selectionMode;

  protected boolean isSelected;

  public CheckNode() {
    this(null);
  }

  /*Contructor class whcih takes the current user object which resemble the current node the user is working on*/
  public CheckNode(Object userObject) {
    this(userObject, true, false);
  }

  /*Constructor with Two parameters which will take the current node object
   * and the selection made and wether that node allows children or not*/
  public CheckNode(Object userObject, boolean allowsChildren,
      boolean isSelected) {
    super(userObject, allowsChildren);
    this.isSelected = isSelected;
    //Enumeration e = children.elements();
    
    int count=0;
    //count=;
   /* for(int i=0;i<Combo.roots.length;i++)
    {
    	if(Combo.roots[i].toString().equals(this));
    	
    }*/
    
    if(this.allowsChildren)
    {
    	setSelectionMode(DIG_IN_SELECTION);
    }
    
    else
    {
    	setSelectionMode(SINGLE_SELECTION);
    }
    
  }

  /*This fuction used for setting the selection mode to true or false*/
  public void setSelectionMode(int mode) {
    selectionMode = mode;
  }

  /*This function is used to get the selection mode.*/
  public int getSelectionMode() {
    return selectionMode;
  }
  
  /*This function is used to makje the node seleted or unselected*/

  public void setSelected(boolean isSelected) {
    this.isSelected = isSelected;  
    if ((selectionMode == DIG_IN_SELECTION) && (children != null)) {
      Enumeration e = children.elements();
      while (e.hasMoreElements()) {
        CheckNode node = (CheckNode) e.nextElement();
        node.setSelected(isSelected); 
       // System.out.println(node.getParent().toString());
      //System.out.println("i am here");        
      } 
      
    }

    if(selectionMode == SINGLE_SELECTION){
    	
    	
    	System.out.println("You are here");
        
    	/*Enumeration e = children.elements();
        while (e.hasMoreElements()) {
               	
          CheckNode node = (CheckNode) e.nextElement();
         //node.getParent()
        //System.out.println("i am here");        
       }*/ 
    	
    }
  }

  /*This function returns the sleected status of a node.*/
  public boolean isSelected() {   
	  return isSelected;
  }  
}