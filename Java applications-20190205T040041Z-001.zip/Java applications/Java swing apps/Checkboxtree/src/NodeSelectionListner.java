import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JTree;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;


/****************************************************
Author - Guru Jagadeesh Babu
Description: NodeSelectionListener classs extends the MouseAdapter classs of java
and this class is used to get the mouse clicked node to do operations on that.
*****************************************************/
class NodeSelectionListener extends MouseAdapter {
	    JTree tree;
	    NodeSelectionListener(JTree tree) {
	      this.tree = tree;
	    }
	    
	    
	   /*This function is used to get the mouse clicked location which is used to get the node get clicked.*/ 
	    public void mouseClicked(MouseEvent e) {
	      int x = e.getX();
	      int y = e.getY();
	      int row = tree.getRowForLocation(x, y);
	      TreePath  path = tree.getPathForRow(row);
	      //TreePath  path = tree.getSelectionPath();
	      if (path != null) {
	        CheckNode node = (CheckNode)path.getLastPathComponent();
	        boolean isSelected = ! (node.isSelected());
	        node.setSelected(isSelected);

	        if (node.getSelectionMode() == CheckNode.DIG_IN_SELECTION){
	     	    //System.out.println("selection is ");
	        	if (isSelected) {
	            tree.expandPath(path);
	          } 
	        	
	        	else {
	        	  CheckNode root=(CheckNode)node.getParent();
		        	root.setSelected(isSelected); 
		        	System.out.println("string is"+root.toString());
		        	for(int i=0;i<Combo.roots.length;i++)
		        	{
		        		if(Combo.roots[i].equals(root.toString())){
		        			Combo.roots[i].setSelected(isSelected);
		        		}
		        	}
		        	
	            //tree.collapsePath(path);
	          }	          
	        }

	        else
	        {
	        	System.out.println("selection is ");
	        	if(isSelected)
	        	{	    	
	        		CheckNode root=(CheckNode)node.getParent();
	        		root.setSelected(isSelected);
	        		System.out.println("selection is "+root.toString()+"and "+isSelected);
	        	
	        	}
	        	
	        }
	        
	       /* else
	        {	  
	        	if (isSelected) {
		            node.setSelected(isSelected);
		          } else {
		        	  //System.out.println("yess");
		        	  //CheckNode root=(CheckNode)node.getParent();
			        	//root.setSelected(isSelected); 
		            //tree.collapsePath(path);
		          }	 
	        }*/
	        
	        ((DefaultTreeModel) tree.getModel()).nodeChanged(node);
	        
	      /* if (row == 0) {
	          //tree.revalidate();
	          //tree.repaint();
	        }*/
	        
	      }
	      
	      tree.revalidate();
          tree.repaint();
          
	    }	    
	  }