import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FilenameFilter;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;



/****************************************************
Author - Guru Jagadeesh Babu
Description: RemoveWindow class extends Jframe which is used to open a remove window
which is used to select a portfolio to be deleted.  
*****************************************************/

class RemoveWindow extends JFrame{
	public RemoveWindow() {
		JPanel panel= new JPanel();
		  JComboBox c = new JComboBox();
		  FilenameFilter filter = new FilenameFilter() {
		        public boolean accept(File directory, String fileName) {
		            return fileName.endsWith(".txt"); //assumes all portfolios are stored within the CURRENT folder as .txt files
		        }
		        };
		  JList displayList = new JList(new File(".//").listFiles(filter));
	        displayList.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
	        JComboBox<JList> combo= new JComboBox<JList>();
	        for(int i=0;i<displayList.getModel().getSize();i++)
	        {
	        	c.addItem(displayList.getModel().getElementAt(i));
	        }
	        c.setEditable(false);
	        c.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent e) {
					try {
						File file= new File(".//"+c.getSelectedItem());
						file.delete();
						dispose();
						repaint();
					} catch (Exception e1) {
						e1.printStackTrace();
					}					
				}	     
	        });
	        
	        setPreferredSize(new Dimension(500, 100));
	        panel.add(c);
	        add(panel);
	        pack();
	        setVisible(true);
	        setLocationRelativeTo(null);
	}
}