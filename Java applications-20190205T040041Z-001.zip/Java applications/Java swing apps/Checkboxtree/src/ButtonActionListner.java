import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Enumeration;

import javax.swing.JTextArea;
import javax.swing.tree.TreeNode;


/****************************************************
Author - Guru Jagadeesh Babu
Description:ButtonActionListner class implemets action listner
for Ok button in a make a new potfolio. This will create a new 
file with all the selected nodes in it with the name given by the user.
*****************************************************/
class ButtonActionListener implements ActionListener {
	    CheckNode root;
	    JTextArea textArea;
	    ButtonActionListener(final CheckNode root, final JTextArea textArea) {
	      this.root = root;
	      this.textArea = textArea;
	    }
	    
	    public void actionPerformed(ActionEvent ev) {
	      Enumeration e = root.breadthFirstEnumeration();
	      while (e.hasMoreElements()) {
	        CheckNode node = (CheckNode) e.nextElement();
	        if (node.isSelected()) {
	          TreeNode[] nodes = node.getPath(); 
	          textArea.append("\n" + nodes[0].toString());	         
	          for (int i = 1; i < nodes.length; i++) {
	            textArea.append("/" + nodes[i].toString());
	          }
	        }
	      }
	    }
	  }