import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JPanel;
import javax.swing.JRadioButton;


/****************************************************
Author - Guru Jagadeesh Babu
Description: ModePanel extends JPanel which implements the action listner
which sets the selection modes for the selected nodes.
*****************************************************/
class ModePanel extends JPanel implements ActionListener {
	    CheckNode[] nodes;
	    CheckNode[] roots;
	    JRadioButton b_single, b_dig_in;
	    ModePanel(CheckNode[] nodes) {
	      this.nodes = nodes;
	      setLayout(new GridLayout(2, 1));
	      ButtonGroup group = new ButtonGroup();
	      add(b_dig_in = new JRadioButton("DIG_IN  "));
	      add(b_single = new JRadioButton("SINGLE  "));
	      group.add(b_dig_in);
	      group.add(b_single);
	      b_dig_in.addActionListener(this);
	      b_single.addActionListener(this);
	      b_dig_in.setSelected(true);
    }

	    public void actionPerformed(ActionEvent e) {
	      int mode;
	      if (b_single == e.getSource()) {	    	 
	        mode = CheckNode.SINGLE_SELECTION; //a leaf is being (de)selected
	      } else {
	        mode = CheckNode.DIG_IN_SELECTION; //a theme is being (de)selected
	      }
	      for (int i = 0; i < nodes.length; i++) {
	        nodes[i].setSelectionMode(mode);	
	      }	      
	    }
	  }
