
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Desktop;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.DisplayMode;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.AreaAveragingScaleFilter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.lang.management.ThreadMXBean;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Enumeration;

import javax.swing.ButtonGroup;
import javax.swing.DefaultListCellRenderer;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTree;
import javax.swing.UIManager;
import javax.swing.border.TitledBorder;
import javax.swing.filechooser.FileSystemView;
import javax.swing.plaf.ColorUIResource;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeCellRenderer;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;


/****************************************************
Author - Guru Jagadeesh Babu
Description: Combo class extends JFrame and creates a main frame frame which containing
the nodes and leafs whcih are taken by parsing annotednodes.csv.This class contains functions for parsing
and displaying the tree.
*****************************************************/
public class Combo extends JFrame {
	public static ArrayList<String> Themes=new ArrayList<String>();
	public static ArrayList<String> Leafs=new ArrayList<String>();
	private ArrayList<String> SelectedNodes=new ArrayList<String>();
	static JPanel panel = new JPanel(new BorderLayout()); 
	 static CheckNode[] roots={	 
			 new CheckNode("All themes"),
	    		new CheckNode("Build environment"),
	    		new CheckNode("Disease"),
	    		new CheckNode("Food consumption"),
	    		new CheckNode("Food production"),
	    				new CheckNode("Social environment"),
	    						new CheckNode("Physical activity"),
	    								new CheckNode("Physiology"),
	    										new CheckNode("Psychology"),
	    												new CheckNode("Weight"),
	    														new CheckNode("Well-being")	    
	 };
	 
	 
/*Main class for the application. Entry point*/	 
  public static void main(String args[]) {
    try {
        UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
    } catch (Exception evt) {}
  
    Combo frame = new Combo();
    frame.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    frame.setVisible(true);
  }
  static CheckNode[] totalnodes=null;
   
  /*Constructor for Combo class, Contains the code for constructing the tree
   * by using all the tree nodes got after parsing the file in the frame*/
  public Combo() {
	  
	    super("PHSC Project");
	    parse();                                             
	    CheckNode[] nodes = new CheckNode[Leafs.size()];
	    
	    
	    for (int i=0;i<Leafs.size();i++) {
	      nodes[i]= new CheckNode(Leafs.get(i)); 
	    }
	    
	    totalnodes=nodes;
	    for(int i=0;i<nodes.length;i++)
	    {
	    	if(Themes.get(i).equals("Environment"))
	    	{
	    		roots[1].add(nodes[i]);
	    	}
	    	if(Themes.get(i).equals("Disease"))
	    	{
	    		roots[2].add(nodes[i]);
	    	}if(Themes.get(i).equals("Consumption"))
	    	{
	    		roots[3].add(nodes[i]);
	    	}
	    	if(Themes.get(i).equals("Production"))
	    	{
	    		roots[4].add(nodes[i]);
	    	}
	    	if(Themes.get(i).equals("Social"))
	    	{
	    		roots[5].add(nodes[i]);
	    	}
	    	if(Themes.get(i).equals("PhysicalActivity"))
	    	{
	    		roots[6].add(nodes[i]);
	    	}
	    	if(Themes.get(i).equals("Physiology"))
	    	{
	    		roots[7].add(nodes[i]);
	    	}
	    	if(Themes.get(i).equals("Psychology"))
	    	{
	    		roots[8].add(nodes[i]);
	    	}
	    	if(Themes.get(i).equals("Weight"))
	    	{
	    		roots[9].add(nodes[i]);
	    	}
	    	if(Themes.get(i).equals("Well-being"))
	    	{
	    		roots[10].add(nodes[i]);
	    	}	    	
	    }
	    
	   
	    
	    roots[0].add(roots[1]);
	    roots[0].add(roots[2]);
	    roots[0].add(roots[3]);
	    roots[0].add(roots[4]);
	    roots[0].add(roots[5]);
	    roots[0].add(roots[6]);
	    roots[0].add(roots[7]);
	    roots[0].add(roots[8]);
	    roots[0].add(roots[9]);
	    roots[0].add(roots[10]);
	    	    	    
	    JTree tree = new JTree(roots[0]);
	    tree.setCellRenderer(new CheckRenderer());
	    tree.getSelectionModel().setSelectionMode(
	    TreeSelectionModel.SINGLE_TREE_SELECTION
	    );
	    
	    tree.putClientProperty("JTree.lineStyle", "None");
	    tree.addMouseListener(new NodeSelectionListener(tree));
	    JScrollPane sp = new JScrollPane(tree);
	    
	    //ModePanel mp = new ModePanel(nodes);
	    
	    //System.out.println(nodes);
	    
	    JTextArea textArea = new JTextArea(3,10);
	    
	    //panel.add(mp,BorderLayout.CENTER);
	    //panel.add(tree);
	    //sp.add(panel);
	    
	    panel.add(sp);
	    JPanel ButtonPanel=new JPanel();
	    JButton newfile=new JButton("Make a new portfolio");
	    JButton Edit=new JButton("Open a portfolio");
	    JButton remove=new JButton("Remove a portfolio");
	    
	    ButtonPanel.add(newfile);
	    ButtonPanel.add(Edit);
	    ButtonPanel.add(remove);
	    
	    Edit.addActionListener(new ActionListener() {
	    	
		@Override
		
		public void actionPerformed(ActionEvent e) {
				EditWindow editfile=new EditWindow();
				
					
			}
		});
	    
	    remove.addActionListener(new ActionListener() {
	    	
			@Override
			public void actionPerformed(ActionEvent e) {
			    new RemoveWindow();
			}
		});
	    
	    newfile.addActionListener(new ActionListener() {
	    	
            public void actionPerformed(ActionEvent e)
            {
            	String filename = JOptionPane.showInputDialog(null,
                        "Give the File Name",
                        "File Name",
                        JOptionPane.QUESTION_MESSAGE);
            	for(int i=0;i<nodes.length;i++)
        	    {
            		if(nodes[i].isSelected())
            		{
            			SelectedNodes.add(nodes[i].toString());
            			           			
            		}
            		
        	    }
            	
            	try {
					WriteFile(filename+".txt");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
        	    }           
        });
	    	    
	     
	   getContentPane().add(panel,BorderLayout.WEST);
	   getContentPane().add(ButtonPanel,BorderLayout.CENTER);	
	   setLocationRelativeTo(null);
	   setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);  
  }



  /*Function to create a file to which the user wants to save his seletion*/
  public void WriteFile(String Name) throws IOException
  {
	  File file=new File(Name);
	  if(!file.exists())
	  {
		  try {
			file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
	  }
	  
	  FileWriter fw= new FileWriter(file.getAbsoluteFile());
	  
	  BufferedWriter writer=new BufferedWriter(fw);

	  for(int i=0;i<SelectedNodes.size();i++){
		  writer.append(SelectedNodes.get(i)+"\n"); 
	  }	   
	  
	  writer.close();
  }
  
  /*Function to parse the annotatedNodes.csv and storing them in a array Themes and leafs which
   * makes roots and nodes of the tree*/
	  public static void parse() {
		  
			String csvFile = "annotatedNodes.csv";
			BufferedReader br = null;
			String line = "";
			String cvsSplitBy = ",";

			try {
				int i=0;
				br = new BufferedReader(new FileReader(csvFile));
				while ((line = br.readLine()) != null) {
					String[] values = line.split(cvsSplitBy);
					Themes.add(values[1]);
					Leafs.add(values[0]);                
				}
				
			}catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				if (br != null) {
					try {
						br.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		  }	  
}

  
  
 




