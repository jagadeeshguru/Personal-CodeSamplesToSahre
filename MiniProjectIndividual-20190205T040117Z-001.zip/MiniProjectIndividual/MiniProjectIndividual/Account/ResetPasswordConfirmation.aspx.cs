﻿using System.Web.UI;

namespace MiniProjectIndividual.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}