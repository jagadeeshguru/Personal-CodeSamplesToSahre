﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MiniProjectIndividual
{
    public partial class User : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Profile_Click(object sender, EventArgs e)
        {
            Response.Write("Hello You can Edit your Profile here");
            /* write code to create textbox*/



        }

        protected void EditQuestions_Click(object sender, EventArgs e)
        {

        }
    }
}