﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MiniProjectIndividual
{
    public partial class Successful : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        

        protected void Submit_Click1(object sender, EventArgs e)
        {
            string Answer1, Answer2, Answer3, Answer4, Answer5, Answer6, Answer7, Answer8, Answer9, Answer10;
            Answer1 = TextBox1.Text;
            Answer2 = TextBox2.Text;
            Answer3 = TextBox3.Text;
            Answer4 = TextBox4.Text;
            Answer5 = TextBox5.Text;
            Answer6 = TextBox6.Text;
            Answer7 = TextBox7.Text;
            Answer8 = TextBox8.Text;
            Answer9 = TextBox9.Text;
            Answer10= TextBox10.Text;


            Int32 verify;
            SqlConnection conn = new SqlConnection();

            SqlCommand cmd1 = new SqlCommand();
            SqlCommand cmd2 = new SqlCommand();
            SqlCommand cmd3 = new SqlCommand();
            SqlCommand cmd4 = new SqlCommand();
            SqlCommand cmd5 = new SqlCommand();
            SqlCommand cmd6 = new SqlCommand();
            SqlCommand cmd7 = new SqlCommand();
            SqlCommand cmd8 = new SqlCommand();
            SqlCommand cmd9 = new SqlCommand();
            SqlCommand cmd10 = new SqlCommand();




            String insertstring = "Insert into UserIdpwd(Q1A,Q2A,Q3A,Q4A,Q5A,Q6A,Q7A,Q8A,Q9A,Q10A) VALUES (Answer1,Answer2,Answer3,Answer4,Answer5,Answer6,Answer7,Answer8,Answer9,Answer10)";

            conn = new SqlConnection(@"Data Source=omisbi3.niunt.niu.edu;Initial Catalog=z1779931;User ID=z1779931;Password=Bw1243$h11");
            

            cmd1 = new SqlCommand(insertstring, conn);

        }

        protected void YourSlam_Click(object sender, EventArgs e)
        {
            Response.Redirect("LoginForm.aspx");
        }
    }
    }
