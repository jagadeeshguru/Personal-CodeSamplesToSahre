﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace MiniProjectIndividual
{
    public partial class LoginForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
                 }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

        protected void Submit_Click(object sender, EventArgs e)
        {
            Int32 verify;
            SqlConnection conn = new SqlConnection();

            SqlCommand cmd1 = new SqlCommand();

            //String insertstring = "Insert into Usernpwd(User_ID,Password) VALUES('sample','sample')" ;
            String insertstring = "Select count(*) from Usernpwd where User_ID='" + TextBox1.Text + "' and Password='" + TextBox2.Text + "'";


            conn = new SqlConnection(@"Data Source=omisbi3.niunt.niu.edu;Initial Catalog=z1779931;User ID=z1779931;Password=Bw1243$h11");

            cmd1 = new SqlCommand(insertstring, conn);

            conn.Open();

            //cmd1.ExecuteNonQuery();
            verify = Convert.ToInt32(cmd1.ExecuteScalar());
            conn.Close();
            if (verify > 0)
            {
                Response.Redirect("User.aspx", true);

            }

            else
            {
                Response.Redirect("Unsuccessful.aspx", true);
            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Register.aspx",true);
        }
    }
}